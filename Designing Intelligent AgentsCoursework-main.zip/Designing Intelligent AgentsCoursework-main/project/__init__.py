from project.ui.app import App
